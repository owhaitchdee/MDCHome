# Furlinks

A platform where potential dog adopters can find dogs who are looking for new homes. The website allows fosters and rescuers to easily post about their rescued and fostered dogs that need to be rehomed.
